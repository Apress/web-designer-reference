Dear reader,

I'm sure most people ignore these "read me" files, but, hey, that's their loss, seeing as there's the odd nugget of information within, which you're now privy to!

Essentially, files within this folder are completed code from the various exercises and examples in Web Designer's Reference. All have been validated at The W3C's website and tested in several browsers (IE6/Win, Opera 7.54/Win, Firefox 1.0/Mac and Safari 1.2.3/Mac, if you're taking notes), but should you find any errors, please inform chris@apress.com and craig@snubcommunications.com, listing the problem, the browser you found the problem on, and the operating system you were using at the time.

For ease of navigation, the file names of the items in this folder contain the chapter number, page number, and section title. Therefore 02_p042_the_head_section.html refers to the section "The head section" found on page 42 of chapter 2.

Note that some minor amendments with regards to layout and also some corrections have occurred between the book going to print and these files being compiled. Also, images have been given prefixes to match the HTML documents. Therefore, if a file in the book is called background_image.gif, it may be called 02_p055_background_image.gif for this collection of files. Also, few of the pages have title element content - you'll have to add that yourself, although the title element itself is present in each case.

In terms of rights, you're free to use any of the files within as you see fit. The only exception is for all photographic images, which are not for use outside of working through the book's exercises (unless my written permission has been sent to you).

Finally, if you see .DS_Store documents peppered throughout the archive, just ignore them (or delete them); they're Mac OS X invisible database files, and are there because these files were compiled on a Mac.

Enjoy the files!


Craig Grannell, December 2004.


----

Change history

December 14, 2004: 1.0 - initial release