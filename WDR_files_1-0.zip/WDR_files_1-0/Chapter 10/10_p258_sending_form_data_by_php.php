<?php
if ($_POST) {
  if (get_magic_quotes_gpc()) {
    foreach ($_POST as $key => $value) {
      $temp = stripslashes($value);
      $_POST[$key] = $temp;
      }
    }
  $to = 'me@example.com';
  $subject = 'Feedback from website';
  // message goes here
$message = "From: " . $_POST['realname'] . "\n";
$message .= "Email: " . $_POST['email'] . "\n";
$message .= "Phone: " . $_POST['phone'] . "\n";
$message .= "Comment: " . $_POST['comment'];
  // headers go here
$headers = "From: feedback@example.com\n";
$headers .= "Reply-To: " . $_POST['email'] . "\n";
$headers .= "Cc: copycat@example.com\n";
$headers .= "Content-type: text/plain; charset=UTF-8";

  $sent = mail($to, $subject, $message, $headers);
  }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title></title>
</head>
<body>

<?php
if (isset($sent)) {
  echo '<p><strong>Thank you for contacting us. Your message will be responded to as soon as possible.</strong></p>';
  }
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<!-- form fields go here -->
</form>

</body>
</html>
