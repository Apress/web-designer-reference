function randomContent()
{
var chosenImage=new Array();
// filenames of images in this array
chosenImage[1]="stream.jpg";
chosenImage[2]="river.jpg";
chosenImage[3]="road.jpg";
var chosenAltCopy=new Array();
// title and alt copy for images goes here
chosenAltCopy[1]="A photo of a stream";
chosenAltCopy[2]="A photo of a river";
chosenAltCopy[3]="A photo of a road";

var getRan=Math.floor(Math.random()*chosenImage.length);
if (getRan==0)
getRan=1;

document.write('<img src=\"assets/random_images/'+chosenImage[getRan]+'" alt=\"'+chosenAltCopy[getRan]+'\" width=\"300\" height=\"300\" class=\"imageBorder\" />');
}